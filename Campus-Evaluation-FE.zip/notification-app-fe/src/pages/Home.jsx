function Home() {
  return (
    <div className="container">
      <h1>Notification Management System</h1>
      <p>Create, manage and view notifications from a single dashboard.</p>
    </div>
  );
}

export default Home;
