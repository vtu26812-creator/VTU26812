import { useEffect, useState } from "react";
import NotificationForm from "../components/NotificationForm";
import NotificationList from "../components/NotificationList";
import API from "../services/api";

function Dashboard() {
  const [notifications, setNotifications] = useState([]);

  const loadNotifications = async () => {
    const response = await API.get("/notifications");
    setNotifications(response.data);
  };

  useEffect(() => {
    loadNotifications();
  }, []);

  return (
    <div className="container">
      <NotificationForm loadNotifications={loadNotifications} />
      <NotificationList notifications={notifications} />
    </div>
  );
}

export default Dashboard;
