import { useState } from "react";
import API from "../services/api";

function NotificationForm({ loadNotifications }) {
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");

  const submitHandler = async (e) => {
    e.preventDefault();
    await API.post("/notifications", { title, message });
    setTitle("");
    setMessage("");
    loadNotifications();
  };

  return (
    <form onSubmit={submitHandler} className="form">
      <h3>Create Notification</h3>
      <input type="text" placeholder="Notification Title" value={title} onChange={(e)=>setTitle(e.target.value)} required />
      <textarea placeholder="Notification Message" value={message} onChange={(e)=>setMessage(e.target.value)} required />
      <button type="submit">Send Notification</button>
    </form>
  );
}

export default NotificationForm;
