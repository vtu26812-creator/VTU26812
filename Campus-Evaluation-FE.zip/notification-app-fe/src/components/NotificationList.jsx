function NotificationList({ notifications }) {
  return (
    <div className="list">
      <h3>Notifications</h3>
      {notifications.length === 0 ? <p>No Notifications Available</p> :
        notifications.map((item) => (
          <div className="card" key={item.id}>
            <h4>{item.title}</h4>
            <p>{item.message}</p>
          </div>
        ))
      }
    </div>
  );
}

export default NotificationList;
